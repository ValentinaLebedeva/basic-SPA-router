const HomeComponent = {
    render: function () {
        return `
        <section>
        <h1>Home Page</h1>
        <p>Lorem</p>
        </section>
        `;
    }
}

const ItemComponent = {
    render: function () {
        return `
        <section>
        <h1>Item Page</h1>
        <p>Lorem</p>
        </section>
        `;
    }
}

const FavsComponent = {
    render: function () {
        return `
        <section>
        <h1>Favorite Page</h1>
        <p>Lorem</p>
        </section>
        `;
    }
}

const BidsComponent = {
    render: function () {
        return `
        <section>
        <h1>Bids Page</h1>
        <p>Lorem</p>
        </section>
        `;
    }
}

const ErrorComponent = {
    render: function () {
        return `
        <section>
        <h1>Error 404</h1>
        <p>Lorem</p>
        </section>
        `;
    }
}

/* creating array with routes */

const routes = [
    { path: "/", component: HomeComponent },
    { path: "item", component: ItemComponent },
    { path: "favorites", component: FavsComponent },
    { path: "bids", component: BidsComponent }
]

/* function checking components path */

function findComponentByPath(path, routes) {
    return routes.find(function (route) {
        return route.path === path;
    })
}

/* function router that will work when we enter the page or renew it */

function router() {
    //split path to array
    const pathArray = location.hash.split("/");

    // set current path
    let currentPath = pathArray[0] === "" ? "/" : pathArray[1];
    currentPath = currentPath === "" ? "/" : currentPath;

    const { component = ErrorComponent } = findComponentByPath(currentPath, routes) || {};

    // render component on the page
    document.querySelector("#app").innerHTML = component.render()
}


window.addEventListener("load", router);
window.addEventListener("hashchange", router);